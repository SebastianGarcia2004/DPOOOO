package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.excepciones.*;

public class RestauranteTest {

    private Pedido pedido1;
    private ProductoMenu producto1;
    private Restaurante McDonalds;
    private Combo combo1;
    private ArrayList<ProductoMenu> itemsCombo1;
    
    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() throws Exception {
        
        McDonalds = new Restaurante();
        
        pedido1 = new Pedido("Juan Garcia", "Ciudad Montes");
        producto1 = new ProductoMenu("BicMac", 15000);

        ProductoMenu hamburguesa = new ProductoMenu("Hamburguesa", 15000);
        ProductoMenu papas = new ProductoMenu("Papas", 5000);
        ProductoMenu gaseosa = new ProductoMenu("Gaseosa", 3000);
        ProductoMenu postre = new ProductoMenu("Postre", 4000);

        // primer combo
        itemsCombo1 = new ArrayList<>();
        itemsCombo1.add(hamburguesa);
        itemsCombo1.add(papas);
        itemsCombo1.add(gaseosa);
        combo1 = new Combo("Combo Sencillo", 0.15, itemsCombo1); // 15% descuento
    }

    @AfterEach
    void tearDown() throws Exception {
        
    }
    
    // ========== TESTS DE CONSTRUCTOR ==========
    
    @Test
    void testConstructorRestaurante() {
        Restaurante nuevoRestaurante = new Restaurante();
        
        assertNotNull(nuevoRestaurante.getPedidos());
        assertNotNull(nuevoRestaurante.getMenuBase());
        assertNotNull(nuevoRestaurante.getMenuCombos());
        assertNotNull(nuevoRestaurante.getIngredientes());
        
        assertTrue(nuevoRestaurante.getPedidos().isEmpty());
        assertTrue(nuevoRestaurante.getMenuBase().isEmpty());
        assertTrue(nuevoRestaurante.getMenuCombos().isEmpty());
        assertTrue(nuevoRestaurante.getIngredientes().isEmpty());
        
        assertNull(nuevoRestaurante.getPedidoEnCurso());
    }
    
    // test manejo de pedidos
    
    @Test
    void testIniciarPedidoExitoso() throws YaHayUnPedidoEnCursoException {
        McDonalds.iniciarPedido("Maria Lopez", "Zona Rosa");
        
        assertNotNull(McDonalds.getPedidoEnCurso());
        assertEquals("Maria Lopez", McDonalds.getPedidoEnCurso().getNombreCliente());
    }
    
    @Test
    void testIniciarPedidoCuandoYaHayUno() throws YaHayUnPedidoEnCursoException {
        McDonalds.iniciarPedido("Cliente 1", "Direccion 1");
        
        YaHayUnPedidoEnCursoException exception = assertThrows(
            YaHayUnPedidoEnCursoException.class,
            () -> McDonalds.iniciarPedido("Cliente 2", "Direccion 2")
        );
        
        // El pedido original debe seguir siendo el mismo
        assertEquals("Cliente 1", McDonalds.getPedidoEnCurso().getNombreCliente());
    }
    
    @Test
    void testCerrarPedidoSinPedidoEnCurso() {
        NoHayPedidoEnCursoException exception = assertThrows(
            NoHayPedidoEnCursoException.class,
            () -> McDonalds.cerrarYGuardarPedido()
        );
    }
    
    @Test
    void testGetPedidoEnCursoNull() {
        assertNull(McDonalds.getPedidoEnCurso());
    }
    
    @Test
    void testGetPedidoEnCursoExistente() throws YaHayUnPedidoEnCursoException {
        McDonalds.iniciarPedido("Pedro Sanchez", "Chapinero");
        
        Pedido pedidoActual = McDonalds.getPedidoEnCurso();
        assertNotNull(pedidoActual);
        assertEquals("Pedro Sanchez", pedidoActual.getNombreCliente());
    }
    
    // test getters
    
    @Test
    void testGetPedidos() {
        ArrayList<Pedido> pedidos = McDonalds.getPedidos();
        assertNotNull(pedidos);
        assertTrue(pedidos.isEmpty());
    }
    
    @Test
    void testGetMenuBase() {
        ArrayList<ProductoMenu> menu = McDonalds.getMenuBase();
        assertNotNull(menu);
        assertTrue(menu.isEmpty());
    }
    
    @Test
    void testGetMenuCombos() {
        ArrayList<Combo> combos = McDonalds.getMenuCombos();
        assertNotNull(combos);
        assertTrue(combos.isEmpty());
    }
    
    @Test
    void testGetIngredientes() {
        ArrayList<Ingrediente> ingredientes = McDonalds.getIngredientes();
        assertNotNull(ingredientes);
        assertTrue(ingredientes.isEmpty());
    }
    
    // ========== TESTS DE CARGA DE ARCHIVOS ==========
    
    @Test
    void testCargarIngredientesExitoso() throws Exception {
        File archivoIngredientes = crearArchivoIngredientes(
            "Tomate;500\n" +
            "Lechuga;300\n" +
            "Queso;800"
        );
        
        McDonalds.cargarInformacionRestaurante(
            archivoIngredientes,
            crearArchivoVacio("menu.txt"),
            crearArchivoVacio("combos.txt")
        );
        
        assertEquals(3, McDonalds.getIngredientes().size());
        assertEquals("Tomate", McDonalds.getIngredientes().get(0).getNombre());
        assertEquals(500, McDonalds.getIngredientes().get(0).getCostoAdicional());
    }
    
    @Test
    void testCargarIngredientesRepetidos() throws Exception {
        File archivoIngredientes = crearArchivoIngredientes(
            "Tomate;500\n" +
            "Lechuga;300\n" +
            "Tomate;600"
        );
        
        IngredienteRepetidoException exception = assertThrows(
            IngredienteRepetidoException.class,
            () -> McDonalds.cargarInformacionRestaurante(
                archivoIngredientes,
                crearArchivoVacio("menu.txt"),
                crearArchivoVacio("combos.txt")
            )
        );
    }
    
    @Test
    void testCargarMenuExitoso() throws Exception {
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Cuarto de Libra;18000\n" +
            "Papas Grandes;8000"
        );
        
        McDonalds.cargarInformacionRestaurante(
            crearArchivoVacio("ingredientes.txt"),
            archivoMenu,
            crearArchivoVacio("combos.txt")
        );
        
        assertEquals(3, McDonalds.getMenuBase().size());
        assertEquals("BicMac", McDonalds.getMenuBase().get(0).getNombre());
        assertEquals(15000, McDonalds.getMenuBase().get(0).getPrecio());
    }
    
    @Test
    void testCargarMenuConProductosRepetidos() throws Exception {
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Papas Grandes;8000\n" +
            "BicMac;16000"
        );
        
        ProductoRepetidoException exception = assertThrows(
            ProductoRepetidoException.class,
            () -> McDonalds.cargarInformacionRestaurante(
                crearArchivoVacio("ingredientes.txt"),
                archivoMenu,
                crearArchivoVacio("combos.txt")
            )
        );
    }
    
    @Test
    void testCargarCombosExitoso() throws Exception {
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Papas Grandes;8000\n" +
            "Coca Cola;5000"
        );
        
        File archivoCombos = crearArchivoCombos(
            "Combo BicMac;10%;BicMac;Papas Grandes;Coca Cola"
        );
        
        McDonalds.cargarInformacionRestaurante(
            crearArchivoVacio("ingredientes.txt"),
            archivoMenu,
            archivoCombos
        );
        
        assertEquals(1, McDonalds.getMenuCombos().size());
        assertEquals("Combo BicMac", McDonalds.getMenuCombos().get(0).getNombre());
       
    }
    
    @Test
    void testCargarCombosConProductoFaltante() throws Exception {
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Papas Grandes;8000"
        );
        
        File archivoCombos = crearArchivoCombos(
            "Combo Especial;15%;BicMac;Coca Cola" 
        );
        
        ProductoFaltanteException exception = assertThrows(
            ProductoFaltanteException.class,
            () -> McDonalds.cargarInformacionRestaurante(
                crearArchivoVacio("ingredientes.txt"),
                archivoMenu,
                archivoCombos
            )
        );
    }
    
    @Test
    void testCargarCombosRepetidos() throws Exception {
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Papas Grandes;8000\n" +
            "Coca Cola;5000"
        );
        
        File archivoCombos = crearArchivoCombos(
            "Combo BicMac;10%;BicMac;Papas Grandes\n" +
            "Combo BicMac;15%;BicMac;Coca Cola"
        );
        
        ProductoRepetidoException exception = assertThrows(
            ProductoRepetidoException.class,
            () -> McDonalds.cargarInformacionRestaurante(
                crearArchivoVacio("ingredientes.txt"),
                archivoMenu,
                archivoCombos
            )
        );
    }
    
    @Test
    void testCargarArchivoConFormatoInvalido() throws Exception {
        File archivoIngredientes = crearArchivoIngredientes(
            "Tomate;precio_invalido\n" +
            "Lechuga;300"
        );
        
        NumberFormatException exception = assertThrows(
            NumberFormatException.class,
            () -> McDonalds.cargarInformacionRestaurante(
                archivoIngredientes,
                crearArchivoVacio("menu.txt"),
                crearArchivoVacio("combos.txt")
            )
        );
    }
    
    @Test
    void testCargarInformacionCompleta() throws Exception {
        File archivoIngredientes = crearArchivoIngredientes("Tomate;500\n" +"Lechuga;300\n" +"Queso Extra;800");
        
        File archivoMenu = crearArchivoMenu(
            "BicMac;15000\n" +
            "Cuarto de Libra;18000\n" +
            "Papas Grandes;8000\n" +
            "Coca Cola;5000"
        );
        
        File archivoCombos = crearArchivoCombos(
            "Combo BicMac;10%;BicMac;Papas Grandes;Coca Cola\n" +
            "Combo Cuarto;15%;Cuarto de Libra;Papas Grandes;Coca Cola"
        );
        
        McDonalds.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
        
        assertEquals(3, McDonalds.getIngredientes().size());
        assertEquals(4, McDonalds.getMenuBase().size());
        assertEquals(2, McDonalds.getMenuCombos().size());
    }
    
   
    
       
    //metodos de ayuda
    
    private File crearArchivoIngredientes(String contenido) throws IOException {
        return crearArchivo("ingredientes.txt", contenido);
    }
    
    private File crearArchivoMenu(String contenido) throws IOException {
        return crearArchivo("menu.txt", contenido);
    }
    
    private File crearArchivoCombos(String contenido) throws IOException {
        return crearArchivo("combos.txt", contenido);
    }
    
    private File crearArchivoVacio(String nombre) throws IOException {
        return crearArchivo(nombre, "");
    }
    
    private File crearArchivo(String nombre, String contenido) throws IOException {
        File archivo = tempDir.resolve(nombre).toFile();
        try (FileWriter writer = new FileWriter(archivo)) {
            writer.write(contenido);
        }
        return archivo;
    }
}
