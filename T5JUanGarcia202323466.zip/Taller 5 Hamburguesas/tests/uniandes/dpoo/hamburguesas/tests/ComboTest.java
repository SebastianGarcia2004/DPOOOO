package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest {

    private Combo combo1;
    private Combo combo2;
    private ArrayList<ProductoMenu> itemsCombo1;
    private ArrayList<ProductoMenu> itemsCombo2;
    
    @BeforeEach
    void setUp() throws Exception {
       
        ProductoMenu hamburguesa = new ProductoMenu("Hamburguesa", 15000);
        ProductoMenu papas = new ProductoMenu("Papas", 5000);
        ProductoMenu gaseosa = new ProductoMenu("Gaseosa", 3000);
        ProductoMenu postre = new ProductoMenu("Postre", 4000);
        
        //primer combo
        itemsCombo1 = new ArrayList<>();
        itemsCombo1.add(hamburguesa);
        itemsCombo1.add(papas);
        itemsCombo1.add(gaseosa);
        
        //segundo combo
        itemsCombo2 = new ArrayList<>();
        itemsCombo2.add(hamburguesa);
        itemsCombo2.add(papas);
        itemsCombo2.add(gaseosa);
        itemsCombo2.add(postre);
        
        
        combo1 = new Combo("Combo Sencillo", 0.85, itemsCombo1);
        combo2 = new Combo("Combo Especial", 0.8, itemsCombo2);
    }
    
    @Test
    void testGetNombre() {
        assertEquals("Combo Sencillo", combo1.getNombre(), "El nombre del combo no es el esperado");
        assertEquals("Combo Especial", combo2.getNombre(), "El nombre del combo no es el esperado");
    }
    
    @Test
    void testGetPrecio() {
        // Precio total Combo1: 15000 + 5000 + 3000 = 23000
        // Con descuento del 15%: 23000 * 0.85 = 19550
        int precioEsperadoCombo1 = 19550;
        
        // Precio total Combo2: 15000 + 5000 + 3000 + 4000 = 27000
        // Con descuento del 20%: 27000 * 0.8 = 21600
        int precioEsperadoCombo2 = 21600;
        
        assertEquals(precioEsperadoCombo1, combo1.getPrecio(), "El precio del Combo Sencillo no es el esperado");
        assertEquals(precioEsperadoCombo2, combo2.getPrecio(), "El precio del Combo Especial no es el esperado");
    }
    
    @Test
    void testGenerarTextoFactura() {
    	
    	String espacio = "            ";
        String textoFacturaEsperado1 = "Combo Combo Sencillo\n Descuento: 0.85\n"+espacio+"19550\n";
        String textoFacturaEsperado2 = "Combo Combo Especial\n Descuento: 0.8\n"+espacio+"21600\n";
        
        assertEquals(textoFacturaEsperado1, combo1.generarTextoFactura(), 
                    "El texto de la factura del Combo Sencillo no es el esperado");
        assertEquals(textoFacturaEsperado2, combo2.generarTextoFactura(), 
                "El texto de la factura del Combo Sencillo no es el esperado");
       
    }
}