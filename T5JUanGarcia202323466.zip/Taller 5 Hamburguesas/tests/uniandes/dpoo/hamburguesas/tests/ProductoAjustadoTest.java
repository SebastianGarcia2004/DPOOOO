package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;


public class ProductoAjustadoTest {

	private ProductoMenu ProductoMenu1;
	private ProductoAjustado ProductoAjustado1;
	@BeforeEach
	 void setUp( ) throws Exception
    {
		ProductoMenu1 = new ProductoMenu( "BigMac", 20000 );
		ProductoAjustado1 = new ProductoAjustado( ProductoMenu1 );
		
		Ingrediente queso = new Ingrediente("Queso adicional", 2000);
		Ingrediente tocineta = new Ingrediente("Tocineta", 2500);
		
		ProductoAjustado1.agregados.add(queso);
		ProductoAjustado1.agregados.add(tocineta);
		
    }
	@AfterEach
	    void tearDown( ) throws Exception
	    {
	    }
	
	@Test
    void testGetNombre( )
    {
        assertEquals( "BigMac", ProductoMenu1.getNombre( ), "El nombre del menu no es el esperado." );
        assertEquals( "BigMac", ProductoAjustado1.getNombre( ), "El nombre del menu ajustado no es el esperado." );
    }
	
	@Test
  	void testGetPrecio() 
	{
		assertEquals(20000 , ProductoMenu1.getPrecio() ,"El precio no fue el esperado" );
		assertEquals(24500 , ProductoAjustado1.getPrecio() ,"El precio no fue el esperado" );
	
	}
	@Test
	void testGenerarTextoFactura()
	{
	 
	    Ingrediente cebolla = new Ingrediente("Cebolla", 1000);
	    ProductoAjustado1.eliminados.add(cebolla);
	
	    String textoEsperado = "BigMac +Queso adicional 2000 +Tocineta 2500 -Cebolla 24500\n";
	    
	
	    assertEquals(textoEsperado, ProductoAjustado1.generarTextoFactura(), 
	                "El texto de la factura no coincide con el formato esperado");
	}
}
