package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;


public class PedidoTest {

	private ProductoMenu producto1;
	private Pedido pedido1;
	
	@BeforeEach
	void setUp( ) throws Exception
    {
	pedido1 = new Pedido("Juan Garcia" , "Ciudad Montes" );
	producto1 = new ProductoMenu ("BicMac" , 15000);
    }
	
	@AfterEach
	void tearDown( ) throws Exception
	{
	}
	
	@Test
	void testGetId () 
	{
	int id = pedido1.getIdPedido();
    assertTrue(id >= 0, "El número de Id pedido es incorrecto");
	}
	@Test 
	void getNombreCliente() {
	assertEquals("Juan Garcia" , pedido1.getNombreCliente() , "El nombre del cliente es incorrecto");
	}
	@Test
	void agregarNuevoProductoTest() {
		
	assertEquals(0, pedido1.getPrecioTotalPedido(), "El precio inicial del pedido vacío debería ser 0");	
	pedido1.agregarProducto(producto1);
	assertEquals(15000 , pedido1.getPrecioNetoPedido(), "El precio agregado es incorrecto");		
	}
	@Test
	void getPrecioTotalPedido() {
	pedido1.agregarProducto(producto1);
	assertEquals(17850 , pedido1.getPrecioTotalPedido());		
	}
	
	void getPrecioIvaPedido() {
		
		pedido1.agregarProducto(producto1);
		
		double iva = pedido1.getPrecioNetoPedido() * 0.19;
		
		assertEquals(iva , pedido1.getPrecioIVAPedido(), "El iva es incorrecto");	
		assertEquals(2850 , iva , "El iva es incorrecto");	
			
		}
	@Test
	void testGenerarTextoFacturaConDebug() {
	 
	    pedido1.agregarProducto(producto1);
	    
	   
	    StringBuffer expected = new StringBuffer();
	    expected.append("Cliente: " + pedido1.getNombreCliente() + "\n");
	    expected.append("Dirección: " + pedido1.getDireccion() + "\n");
	    expected.append("----------------\n");
	    expected.append(producto1.generarTextoFactura());
	    expected.append("----------------\n");
	    expected.append("Precio Neto: " + pedido1.getPrecioNetoPedido() + "\n");
	    expected.append("IVA: " + pedido1.getPrecioIVAPedido() + "\n");
	    expected.append("Precio Total: " + pedido1.getPrecioTotalPedido() + "\n");
	       
	}
}
