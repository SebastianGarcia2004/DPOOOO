package uniandes.dpoo.hamburguesas.mundo;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import uniandes.dpoo.hamburguesas.excepciones.HamburguesaException;
import uniandes.dpoo.hamburguesas.excepciones.NoHayPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;

public class Consola2 {
    private static Restaurante restaurante;
    private static Scanner scanner;
    
    public static void main(String[] args) {
        restaurante = new Restaurante();
        scanner = new Scanner(System.in);
        
        cargarInformacionRestaurante();
    
        boolean continuar = true;
        while (continuar) {
            mostrarMenu();
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    mostrarMenuRestaurante();
                    break;
                case 2:
                    iniciarPedido();
                    break;
                case 3:
                    agregarElementoAlPedido();
                    break;
                case 4:
                    cerrarPedido();
                    break;
                case 5:
                    consultarPedido();
                    break;
                case 0:
                    continuar = false;
                    System.out.println("¡Gracias por usar nuestro restaurante!");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor seleccione una opción del 0 al 5.");
            }
            
            if (continuar) {
                System.out.println("\nPresione Enter para continuar...");
                scanner.nextLine();
            }
        }
        
        scanner.close();
    }
    
    private static void cargarInformacionRestaurante() {
        try {
            File archivoIngredientes = new File("./data/ingredientes.txt");
            File archivoMenu = new File("./data/menu.txt");
            File archivoCombos = new File("./data/combos.txt");
            
            restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);
            System.out.println("Información del restaurante cargada exitosamente.");
        } catch (HamburguesaException | IOException e) {
            System.out.println("Error cargando la información del restaurante: " + e.getMessage());
            System.out.println("Continuando con menú vacío...");
        }
    }
    
    private static void mostrarMenu() {
        System.out.println("\n=== RESTAURANTE DE HAMBURGUESAS ===");
        System.out.println("1. Mostrar menú");
        System.out.println("2. Iniciar pedido");
        System.out.println("3. Agregar elemento al pedido");
        System.out.println("4. Cerrar pedido");
        System.out.println("5. Consultar pedido");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static int leerOpcion() {
        try {
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea
            return opcion;
        } catch (Exception e) {
        	
            scanner.nextLine(); 
            return -1;
        }
    }
    
    private static void mostrarMenuRestaurante() {
        System.out.println("\n=== MENÚ DEL RESTAURANTE ===");
        
        // Mostrar productos base
        ArrayList<ProductoMenu> menuBase = restaurante.getMenuBase();
        if (!menuBase.isEmpty()) {
            System.out.println("\n--- PRODUCTOS BASE ---");
            for (int i = 0; i < menuBase.size(); i++) {
                ProductoMenu producto = menuBase.get(i);
                System.out.println((i + 1) + ". " + producto.getNombre() + " - $" + producto.getPrecio());
            }
        } else {
            System.out.println("No hay productos base disponibles.");
        }
        
        // Mostrar combos
        ArrayList<Combo> menuCombos = restaurante.getMenuCombos();
        if (!menuCombos.isEmpty()) {
            System.out.println("\n--- COMBOS ---");
            for (int i = 0; i < menuCombos.size(); i++) {
                Combo combo = menuCombos.get(i);
                System.out.println((i + 1) + ". " + combo.getNombre() + " - $" + combo.getPrecio());
            }
        } else {
            System.out.println("No hay combos disponibles.");
        }
        
        // Mostrar ingredientes
        ArrayList<Ingrediente> ingredientes = restaurante.getIngredientes();
        if (!ingredientes.isEmpty()) {
            System.out.println("\n--- INGREDIENTES ADICIONALES ---");
            for (int i = 0; i < ingredientes.size(); i++) {
                Ingrediente ingrediente = ingredientes.get(i);
                System.out.println((i + 1) + ". " + ingrediente.getNombre() + " - $" + ingrediente.getCostoAdicional());
            }
        } else {
            System.out.println("No hay ingredientes adicionales disponibles.");
        }
    }
    
    private static void iniciarPedido() {
        try {
            System.out.print("Por favor ingrese su nombre: ");
            String nombre = scanner.nextLine().trim();
            
            if (nombre.isEmpty()) {
                System.out.println("El nombre no puede estar vacío.");
                return;
            }
            
            System.out.print("Por favor ingrese su dirección: ");
            String direccion = scanner.nextLine().trim();
            
            if (direccion.isEmpty()) {
                System.out.println("La dirección no puede estar vacía.");
                return;
            }
            
            restaurante.iniciarPedido(nombre, direccion);
            Pedido pedidoCreado = restaurante.getPedidoEnCurso();
            
            System.out.println("\n¡Pedido iniciado exitosamente!");
            System.out.println("ID del pedido: " + pedidoCreado.getIdPedido());
            System.out.println("Cliente: " + pedidoCreado.getNombreCliente());
            System.out.println("Dirección: " + pedidoCreado.getDireccion());
            System.out.println("\nAhora puede agregar elementos al pedido (Opción 3).");
            
        } catch (YaHayUnPedidoEnCursoException e) {
            System.out.println("\nYa hay un pedido en curso.");
            Pedido pedidoActual = restaurante.getPedidoEnCurso();
            System.out.println("Cliente actual: " + pedidoActual.getNombreCliente());
            System.out.println("ID del pedido actual: " + pedidoActual.getIdPedido());
            System.out.println("Debe cerrar el pedido actual antes de iniciar uno nuevo.");
        }
    }
    
    private static void agregarElementoAlPedido() {
        Pedido pedidoActual = restaurante.getPedidoEnCurso();
        
        if (pedidoActual == null) {
            System.out.println("No hay un pedido en curso. Debe iniciar un pedido primero (Opción 2).");
            return;
        }
        
        System.out.println("\n=== AGREGAR ELEMENTO AL PEDIDO ===");
        System.out.println("¿Qué desea agregar?");
        System.out.println("1. Producto del menú base");
        System.out.println("2. Combo");
        System.out.println("0. Volver al menú principal");
        System.out.print("Seleccione una opción: ");
        
        int tipo = leerOpcion();
        
        switch (tipo) {
            case 1:
                agregarProductoBase();
                break;
            case 2:
                agregarCombo();
                break;
            case 0:
                return;
            default:
                System.out.println("Opción no válida.");
        }
    }
    
    private static void agregarProductoBase() {
        ArrayList<ProductoMenu> menuBase = restaurante.getMenuBase();
        
        if (menuBase.isEmpty()) {
            System.out.println("No hay productos base disponibles.");
            return;
        }
        
        System.out.println("\n--- PRODUCTOS BASE DISPONIBLES ---");
        for (int i = 0; i < menuBase.size(); i++) {
            ProductoMenu producto = menuBase.get(i);
            System.out.println((i + 1) + ". " + producto.getNombre() + " - $" + producto.getPrecio());
        }
        
        System.out.print("Seleccione el número del producto (0 para cancelar): ");
        int seleccion = leerOpcion();
        
        if (seleccion == 0) {
            return;
        }
        
        if (seleccion < 1 || seleccion > menuBase.size()) {
            System.out.println("Selección no válida.");
            return;
        }
        
        ProductoMenu productoSeleccionado = menuBase.get(seleccion - 1);
        
        // Preguntar si desea agregar ingredientes adicionales
        Producto productoFinal = preguntarIngredientesAdicionales(productoSeleccionado);
        
        restaurante.getPedidoEnCurso().agregarProducto((ProductoMenu) productoFinal);
        System.out.println("Producto agregado al pedido: " + productoFinal.getNombre() + " - $" + productoFinal.getPrecio());
    }
    
    private static void agregarCombo() {
        ArrayList<Combo> menuCombos = restaurante.getMenuCombos();
        
        if (menuCombos.isEmpty()) {
            System.out.println("No hay combos disponibles.");
            return;
        }
        
        System.out.println("\n--- COMBOS DISPONIBLES ---");
        for (int i = 0; i < menuCombos.size(); i++) {
            Combo combo = menuCombos.get(i);
            System.out.println((i + 1) + ". " + combo.getNombre() + " - $" + combo.getPrecio());
        }
        
        System.out.print("Seleccione el número del combo (0 para cancelar): ");
        int seleccion = leerOpcion();
        
        if (seleccion == 0) {
            return;
        }
        
        if (seleccion < 1 || seleccion > menuCombos.size()) {
            System.out.println("Selección no válida.");
            return;
        }
        
        Combo comboSeleccionado = menuCombos.get(seleccion - 1);
        restaurante.getPedidoEnCurso().agregarProducto(comboSeleccionado);
        System.out.println("Combo agregado al pedido: " + comboSeleccionado.getNombre() + " - $" + comboSeleccionado.getPrecio());
    }
    
    private static Producto preguntarIngredientesAdicionales(ProductoMenu productoBase) {
        ArrayList<Ingrediente> ingredientes = restaurante.getIngredientes();
        
        if (ingredientes.isEmpty()) {
            return productoBase;
        }
        
        System.out.print("¿Desea agregar ingredientes adicionales? (s/n): ");
        String respuesta = scanner.nextLine().trim().toLowerCase();
        
        if (!respuesta.equals("s") && !respuesta.equals("si")) {
            return productoBase;
        }
        return productoBase;
    }
    
    
    
    
    private static void cerrarPedido() {
        try {
            Pedido pedidoActual = restaurante.getPedidoEnCurso();
            
            if (pedidoActual == null) {
                System.out.println("No hay un pedido en curso para cerrar.");
                return;
            }
            
            System.out.println("\n=== RESUMEN DEL PEDIDO ===");
            System.out.println("Cliente: " + pedidoActual.getNombreCliente());
            System.out.println("Dirección: " + pedidoActual.getDireccion());
            System.out.println("ID del pedido: " + pedidoActual.getIdPedido());
            System.out.println("\nFactura:");
            System.out.println(pedidoActual.generarTextoFactura());
            
            System.out.print("¿Confirma el pedido? (s/n): ");
            String confirmacion = scanner.nextLine().trim().toLowerCase();
            
            if (confirmacion.equals("s") || confirmacion.equals("si")) {
                
                File carpetaFacturas = new File("./facturas");
                if (!carpetaFacturas.exists()) {
                    carpetaFacturas.mkdirs();
                    System.out.println("Carpeta 'facturas' creada.");
                }
                
                restaurante.cerrarYGuardarPedido();
                System.out.println("¡Pedido cerrado y factura guardada exitosamente!");
            } else {
                System.out.println("Pedido no confirmado. El pedido sigue en curso.");
            }
            
        } catch (NoHayPedidoEnCursoException e) {
            System.out.println("No hay un pedido en curso para cerrar.");
        } catch (IOException e) {
            System.out.println("Error guardando la factura: " + e.getMessage());
        }
    }
    
    
    
    
    
    
    
    
    
    private static void consultarPedido() {
        ArrayList<Pedido> pedidos = restaurante.getPedidos();
        
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos cerrados para consultar.");
            return;
        }
        
        System.out.print("Ingrese el ID del pedido a consultar: ");
        try {
            int idPedido = scanner.nextInt();
            scanner.nextLine(); 
            
            Pedido pedidoEncontrado = null;
            for (Pedido pedido : pedidos) {
                if (pedido.getIdPedido() == idPedido) {
                    pedidoEncontrado = pedido;
                    break;
                }
            }
            
            if (pedidoEncontrado != null) {
                System.out.println("\n=== INFORMACIÓN DEL PEDIDO ===");
                System.out.println(pedidoEncontrado.generarTextoFactura());
            } else {
                System.out.println("No se encontró un pedido con el ID: " + idPedido);
            }
            
        } catch (Exception e) {
            scanner.nextLine(); 
            System.out.println("ID no válido. Debe ser un número entero.");
        }
    }
}