package uniandes.dpoo.aerolinea.persistencia;

public interface IPersistenciaAerolinea {
		
		public void cargarAerolinea(String archivo, Aerolinea aerolinea);
		
		public void salvarAerolinea(String archivo, Aerolinea aerolinea);

}
	
