package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente {

	public static String NATURAL = "Natural";
	private String nombre;
	
	
	//constructor
	public ClienteNatural(String nombre) {
		this.nombre = nombre;
	}
	
	
	
	//getters
	
	public String getTipoeCliente() {
		
		return NATURAL;
	}

	

	public String getIdentificador() {
		return nombre;
	}

	
}