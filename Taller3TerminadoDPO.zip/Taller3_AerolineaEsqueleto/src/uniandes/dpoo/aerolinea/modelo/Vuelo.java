package uniandes.dpoo.aerolinea.modelo;
import java.util.ArrayList;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;



public class Vuelo {

	private Avion avion;
	private String fecha;
	private Ruta ruta;
	private ArrayList<Tiquete>tiquetes;
	
    //constructor
	public Vuelo(Avion avion, String fecha, Ruta ruta) {
		this.avion = avion;
		this.fecha = fecha;
		this.ruta = ruta;
		tiquetes = new ArrayList<Tiquete>();
	}
	
	
	//getters
	public Ruta getRuta() {
		return ruta;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public Avion getAvion() {
		return avion;
	}
	
	public ArrayList<Tiquete> getTiquetes() {
		return tiquetes;
	}
	
}