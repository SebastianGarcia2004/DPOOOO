package uniandes.dpoo.aerolinea.modelo.tarifas;

public abstract class CalculadoraTarifas {

	public double IMPUESTO = 0.28;
	
	//Metodos
	
	public abstract int calcularTarifa(Vuelo vuelo , Cliente cliente);
	
	protected abstract int calcularCostoBase(Vuelo vuelo , Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected abstract int calcularDistanciaVuelo(Ruta ruta);
	
	protected int calcularValorImpuestos(int costoBase) {
		return (int)(costoBase*IMPUESTO);
		
	}
	
	
	
}
