package uniandes.dpoo.aerolinea.modelo;

public class Avion {
	
	//Atributos
	private int capacidad;
	private String nombre;
	
	//Metodos
	
	public Avion(String nombre, int capacidad) {
		this.nombre = nombre;
		this.capacidad = capacidad;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public String getNombre() {
		return nombre;
	}
	
	
}